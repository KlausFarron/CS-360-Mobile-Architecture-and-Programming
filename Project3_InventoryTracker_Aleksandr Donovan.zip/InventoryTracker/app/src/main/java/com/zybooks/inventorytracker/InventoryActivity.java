package com.zybooks.inventorytracker;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Switch;
import android.widget.Toast;
import android.telephony.SmsManager;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

/**
 * Displays the current inventory screen and manages the interaction of the inventory.
 * Retrieves user-specific inventory data from the SQLite database, displays
 * the data in a RecyclerView.
 * Handles SMS notification permissions and alerts.
 */
public class InventoryActivity extends AppCompatActivity {

    // UI components used on the inventory screen
    private Button m_buttonAddItem;
    private RecyclerView m_recyclerView;
    private Switch m_switchSMS;

    // Database helper and adapter used to manage and display inventory data
    private DatabaseHelper m_databaseHelper;
    private InventoryAdapter m_inventoryAdapter;
    private ArrayList<InventoryItem> m_itemList;

    // Stores the username of the currently logged-in user
    private String m_username;

    // Track whether SMS notifications are enabled
    private boolean m_smsEnabled = false;

    // Stores saved app settings
    private SharedPreferences m_preferences;

    // Launcher for SMS permission request
    private final ActivityResultLauncher<String> m_requestPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {
                    m_smsEnabled = true;
                    saveSmsPreference(true);
                    m_switchSMS.setChecked(true);

                    Toast.makeText(InventoryActivity.this,
                            "SMS permission granted.",
                            Toast.LENGTH_SHORT).show();
                }
                else {
                    m_smsEnabled = false;
                    m_switchSMS.setChecked(false);

                    Toast.makeText(InventoryActivity.this,
                            "SMS permission denied. The app will continue without SMS notifications.",
                            Toast.LENGTH_LONG).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_inventory);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Connect Java variables to layout controls
        m_buttonAddItem = findViewById(R.id.buttonAddItem);
        m_recyclerView = findViewById(R.id.recyclerView);
        m_switchSMS = findViewById(R.id.switchSMS);

        // Initializes the database helper and retrieves the current username
        m_databaseHelper = new DatabaseHelper(this);

        m_username = getIntent().getStringExtra("username");

        // Initializes shared preferences
        m_preferences = getSharedPreferences("InventoryTrackerPrefs", MODE_PRIVATE);

        // Loads the saved SMS setting for the current user
        m_smsEnabled = m_preferences.getBoolean("sms_enabled_" + m_username, false);
        m_switchSMS.setChecked(m_smsEnabled);

        // Creates the list that stores inventory items for the logged-in user
        m_itemList = new ArrayList<>();

        // Initializes the RecyclerView and connects it to the inventory adapter
        m_recyclerView.setLayoutManager(new LinearLayoutManager(this));
        m_inventoryAdapter = new InventoryAdapter(m_itemList, m_databaseHelper, m_username);
        m_recyclerView.setAdapter(m_inventoryAdapter);

        // Loads the current user's inventory items from the database
        loadInventoryItems();

        // Opens the Add Item screen when the user selects Add Item
        m_buttonAddItem.setOnClickListener(v -> {
            Intent intent = new Intent(InventoryActivity.this, AddItemActivity.class);
            intent.putExtra("username", m_username);
            startActivity(intent);
        });

        // Enables or disables SMS notifications based on the switch state
        m_switchSMS.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                checkSmsPermission();
            }
            else {
                m_smsEnabled = false;

                // Saves SMS preference when switch is turned off
                saveSmsPreference(false);

                Toast.makeText(InventoryActivity.this,
                        "SMS notifications turned off.",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    /**
     * Retrieves all inventory items associated with the current user
     * and updates the RecyclerView display.
     */
    private void loadInventoryItems() {
        m_itemList.clear();

        Cursor cursor = m_databaseHelper.getAllItemsForUser(m_username);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                int itemId = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_ID));
                String itemName = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_NAME));
                int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_QUANTITY));

                m_itemList.add(new InventoryItem(itemId, itemName, quantity));

                // Check for low inventory and send alert
                if (quantity == 0) {
                    sendLowInventoryAlert(itemName, quantity);
                }

            } while (cursor.moveToNext());

            cursor.close();
        }

        m_inventoryAdapter.notifyDataSetChanged();
    }

    /**
     * Checks whether SMS permission has already been granted.
     * If not, requests the permission from the user.
     */
    private void checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {

            m_smsEnabled = true;

            // Saves SMS preference when permission is already granted
            saveSmsPreference(true);

            Toast.makeText(this,
                    "SMS notifications enabled.",
                    Toast.LENGTH_SHORT).show();
        }
        else {
            m_requestPermissionLauncher.launch(Manifest.permission.SEND_SMS);
        }
    }

    // Saves the current user's SMS notification preference
    private void saveSmsPreference(boolean isEnabled) {
        SharedPreferences.Editor editor = m_preferences.edit();
        editor.putBoolean("sms_enabled_" + m_username, isEnabled);
        editor.apply();
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Reload items whenever the user returns to this screen
        loadInventoryItems();
    }

    /**
     * Sends an SMS alert when inventory is low.
     */
    private void sendLowInventoryAlert(String itemName, int quantity) {

        if (!m_smsEnabled) {
            return;
        }

        try {
            String phoneNumber = "1234567890"; // Replace with your test number
            String message = "Alert: " + itemName + " is low in stock. Quantity: " + quantity;

            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);

            Toast.makeText(this,
                    "SMS alert sent.",
                    Toast.LENGTH_SHORT).show();
        }
        catch (Exception e) {
            Toast.makeText(this,
                    "Failed to send SMS.",
                    Toast.LENGTH_SHORT).show();
        }
    }
}