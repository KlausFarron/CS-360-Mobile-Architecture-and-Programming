package com.zybooks.inventorytracker;

/**
 * Stores the item's unique identifier, name, and quantity,
 * and provides access for use in the application.
 */
public class InventoryItem {

    // Unique identifier for the inventory item
    private int m_itemId;
    // Name of the inventory item
    private String m_itemName;
    // Quantity of the inventory item
    private int m_quantity;

    /**
     * Constructs an InventoryItem with the specified values.
     */
    public InventoryItem(int itemId, String itemName, int quantity) {
        m_itemId = itemId;
        m_itemName = itemName;
        m_quantity = quantity;
    }

    // Returns the unique ID of the inventory item.
    public int getItemId() {
        return m_itemId;
    }

    // Returns the name of the inventory item.
    public String getItemName() {
        return m_itemName;
    }

    // returns the quantity of the inventory item.
    public int getQuantity() {
        return m_quantity;
    }
}