package com.zybooks.inventorytracker;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.database.Cursor;

/**
 * Handles the creation and management of the app's SQLite database.
 * responsible for creating, updating, and providing access to
 * user accounts and user-specific inventory data.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    // Database name and version
    private static final String DATABASE_NAME = "InventoryDB.db";
    private static final int DATABASE_VERSION = 2;

    // User table
    public static final String TABLE_USERS = "users";
    public static final String COLUMN_USER_ID = "id";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";

    // Inventory table
    public static final String TABLE_ITEMS = "items";
    public static final String COLUMN_ITEM_ID = "item_id";
    public static final String COLUMN_ITEM_NAME = "item_name";
    public static final String COLUMN_QUANTITY = "quantity";
    public static final String COLUMN_ITEM_USERNAME = "username";


    // Constructor for DatabaseHelper
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    /**
     * Creates the database tables when the database is first initialized.
     * This includes the users table and the inventory items table.
     */
    @Override
    public void onCreate(SQLiteDatabase db) {

        // Create users table
        String createUsersTable = "CREATE TABLE " + TABLE_USERS + " ("
                + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_USERNAME + " TEXT UNIQUE, "
                + COLUMN_PASSWORD + " TEXT)";

        // Create items table
        String createItemsTable = "CREATE TABLE " + TABLE_ITEMS + " ("
                + COLUMN_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_ITEM_NAME + " TEXT, "
                + COLUMN_QUANTITY + " INTEGER, "
                + COLUMN_ITEM_USERNAME + " TEXT)";

        db.execSQL(createUsersTable);
        db.execSQL(createItemsTable);
    }

    // Handles database upgrades by dropping existing tables and recreating them.
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop old tables if they exist
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ITEMS);

        // Recreate tables
        onCreate(db);
    }

    // Inserts a new user into the users table.
    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, values);
        db.close();

        return result != -1;
    }

    // Checks if a username already exists in the users table.
    public boolean usernameExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_USERS + " WHERE " + COLUMN_USERNAME + " = ?",
                new String[]{username}
        );

        boolean exists = cursor.getCount() > 0;
        cursor.close();
        db.close();

        return exists;
    }

    // Validates if the entered username and password match an existing account.
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_USERS + " WHERE " + COLUMN_USERNAME + " = ? AND "
                        + COLUMN_PASSWORD + " = ?",
                new String[]{username, password}
        );

        boolean validUser = cursor.getCount() > 0;
        cursor.close();
        db.close();

        return validUser;
    }

    // Inserts a new inventory item into the items table.
    public boolean addItem(String itemName, int quantity, String username) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_ITEM_NAME, itemName);
        values.put(COLUMN_QUANTITY, quantity);
        values.put(COLUMN_ITEM_USERNAME, username);

        long result = db.insert(TABLE_ITEMS, null, values);
        db.close();

        return result != -1;
    }

    // Retrieves all inventory items from the items table.
    public Cursor getAllItemsForUser(String username) {
        SQLiteDatabase db = this.getReadableDatabase();

        return db.rawQuery(
                "SELECT * FROM " + TABLE_ITEMS + " WHERE " + COLUMN_ITEM_USERNAME + " = ?",
                new String[]{username}
        );
    }

    // Updates an existing inventory item's name and quantity.
    public boolean updateItem(int itemId, String itemName, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_ITEM_NAME, itemName);
        values.put(COLUMN_QUANTITY, quantity);

        int rowsAffected = db.update(
                TABLE_ITEMS,
                values,
                COLUMN_ITEM_ID + " = ?",
                new String[]{String.valueOf(itemId)}
        );

        db.close();
        return rowsAffected > 0;
    }

    // Deletes an inventory item from the items table.
    public boolean deleteItem(int itemId) {
        SQLiteDatabase db = this.getWritableDatabase();

        int rowsDeleted = db.delete(
                TABLE_ITEMS,
                COLUMN_ITEM_ID + " = ?",
                new String[]{String.valueOf(itemId)}
        );

        db.close();
        return rowsDeleted > 0;
    }
}