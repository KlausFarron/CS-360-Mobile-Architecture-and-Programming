package com.zybooks.inventorytracker;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

/**
 * Allows the user to add a new item to the inventory.
 * or update an existing item in the SQLite database.
 */
public class AddItemActivity extends AppCompatActivity {

    // User input fields and buttons for item entry
    private EditText m_editItemName;
    private EditText m_editQuantity;
    private Button m_buttonSaveItem;
    private Button m_buttonCancel;

    // Stores the username of the currently logged-in user
    private String m_username;


    // Database helper used to insert and update inventory records
    private DatabaseHelper m_databaseHelper;

    // Track whether the activity is editing an existing item
    private int m_itemId = -1;
    private boolean m_isEditMode = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_item);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Connect Java variables to layout controls
        m_editItemName = findViewById(R.id.editItemName);
        m_editQuantity = findViewById(R.id.editQuantity);
        m_buttonSaveItem = findViewById(R.id.buttonSaveItem);
        m_buttonCancel = findViewById(R.id.buttonCancel);

        // Initializes database helper and retrieves current user's username
        m_databaseHelper = new DatabaseHelper(this);
        m_username = getIntent().getStringExtra("username");


        // Check whether this screen was opened in edit mode and prefill fields if needed
        if (getIntent().hasExtra("item_id")) {
            m_isEditMode = true;
            m_itemId = getIntent().getIntExtra("item_id", -1);

            String itemName = getIntent().getStringExtra("item_name");
            int quantity = getIntent().getIntExtra("quantity", 0);

            m_editItemName.setText(itemName);
            m_editQuantity.setText(String.valueOf(quantity));
        }

        // Saves a new item or update an existing item
        m_buttonSaveItem.setOnClickListener(v -> {
            String itemName = m_editItemName.getText().toString().trim();
            String quantityText = m_editQuantity.getText().toString().trim();

            if (itemName.isEmpty() || quantityText.isEmpty()) {
                Toast.makeText(AddItemActivity.this,
                        "Please enter both item name and quantity.",
                        Toast.LENGTH_SHORT).show();
            }
            else {
                int quantity = Integer.parseInt(quantityText);

                if (m_isEditMode) {
                    boolean itemUpdated = m_databaseHelper.updateItem(m_itemId, itemName, quantity);

                    if (itemUpdated) {
                        Toast.makeText(AddItemActivity.this,
                                "Item updated successfully.",
                                Toast.LENGTH_SHORT).show();
                        finish();
                    }
                    else {
                        Toast.makeText(AddItemActivity.this,
                                "Failed to update item.",
                                Toast.LENGTH_SHORT).show();
                    }
                }
                else {
                    boolean itemAdded = m_databaseHelper.addItem(itemName, quantity, m_username);;

                    if (itemAdded) {
                        Toast.makeText(AddItemActivity.this,
                                "Item saved successfully.",
                                Toast.LENGTH_SHORT).show();
                        finish();
                    }
                    else {
                        Toast.makeText(AddItemActivity.this,
                                "Failed to save item.",
                                Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        // Closes the activity without saving changes
        m_buttonCancel.setOnClickListener(v -> finish());
    }
}