package com.zybooks.inventorytracker;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

/**
 * The main driver
 * Displays the login screen.
 * Manages user authentication.
 * Allows users to create an account or log in with an existing account.
 */
public class MainActivity extends AppCompatActivity {

    // User input fields and buttons displayed on the login screen
    private EditText m_editUsername;
    private EditText m_editPassword;
    private Button m_buttonLogin;
    private Button m_buttonCreateAccount;

    // Database helper used to access stored user account information
    private DatabaseHelper m_databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Links Java variables to the views defined in the activity_main layout file
        m_editUsername = findViewById(R.id.editUsername);
        m_editPassword = findViewById(R.id.editPassword);
        m_buttonLogin = findViewById(R.id.buttonLogin);
        m_buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        // Initializes the database helper so the app can validate and create user accounts
        m_databaseHelper = new DatabaseHelper(this);

        // Validates the users input and opens the inventory screen if successful credentials
        m_buttonLogin.setOnClickListener(v -> {
            String username = m_editUsername.getText().toString().trim();
            String password = m_editPassword.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(MainActivity.this,
                        "Please enter both username and password.",
                        Toast.LENGTH_SHORT).show();
            }
            else if (m_databaseHelper.checkUser(username, password)) {
                Toast.makeText(MainActivity.this,
                        "Login successful.",
                        Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(MainActivity.this, InventoryActivity.class);
                intent.putExtra("username", username);
                startActivity(intent);
            }
            else {
                Toast.makeText(MainActivity.this,
                        "Invalid username or password.",
                        Toast.LENGTH_SHORT).show();
            }
        });

        // Create a new account after checking that the entered username is not already in use
        m_buttonCreateAccount.setOnClickListener(v -> {
            String username = m_editUsername.getText().toString().trim();
            String password = m_editPassword.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(MainActivity.this,
                        "Please enter both username and password.",
                        Toast.LENGTH_SHORT).show();
            }
            else if (m_databaseHelper.usernameExists(username)) {
                Toast.makeText(MainActivity.this,
                        "Username already exists.",
                        Toast.LENGTH_SHORT).show();
            }
            else {
                boolean userAdded = m_databaseHelper.addUser(username, password);

                if (userAdded) {
                    Toast.makeText(MainActivity.this,
                            "Account created successfully.",
                            Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(MainActivity.this,
                            "Failed to create account.",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}