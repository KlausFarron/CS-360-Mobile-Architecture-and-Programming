package com.zybooks.inventorytracker;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * Connects inventory data to the RecyclerView.
 * Binds each inventory item to a row in the list and handles
 * edit and delete actions for the selected item.
 */
public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.InventoryViewHolder> {

    // Stores the list of inventory items displayed in the RecyclerView
    private List<InventoryItem> m_itemList;

    // Database helper used to delete inventory items from storage
    private DatabaseHelper m_databaseHelper;

    // Stores the username of the currently logged-in user
    private String m_username;

    /**
     * Constructs an InventoryAdapter with the item list, database helper,
     * and current username.
     */
    public InventoryAdapter(List<InventoryItem> itemList, DatabaseHelper databaseHelper, String username) {
        m_itemList = itemList;
        m_databaseHelper = databaseHelper;
        m_username = username;
    }

    @NonNull
    @Override
    public InventoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the layout used for each inventory row in the RecyclerView
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_inventory, parent, false);
        return new InventoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull InventoryViewHolder holder, int position) {
        InventoryItem currentItem = m_itemList.get(position);

        // Displays the current item's name and quantity in the row
        holder.m_textItemName.setText(currentItem.getItemName());
        holder.m_textQuantity.setText(String.valueOf(currentItem.getQuantity()));

        // Open AddItemActivity in edit mode and pass the selected item data
        holder.m_buttonEdit.setOnClickListener(v -> {
            Intent intent = new Intent(v.getContext(), AddItemActivity.class);
            intent.putExtra("item_id", currentItem.getItemId());
            intent.putExtra("item_name", currentItem.getItemName());
            intent.putExtra("quantity", currentItem.getQuantity());
            intent.putExtra("username", m_username);
            v.getContext().startActivity(intent);
        });

        // Deletes the selected item from the database and refresh the displayed list
        holder.m_buttonDelete.setOnClickListener(v -> {
            int itemId = currentItem.getItemId();

            boolean deleted = m_databaseHelper.deleteItem(itemId);

            if (deleted) {
                m_itemList.remove(position);
                notifyDataSetChanged();
            }
        });
    }

    @Override
    public int getItemCount() {
        return m_itemList.size();
    }

    /**
     * Stores the views used for a single inventory row
     * in the RecyclerView.
     */
    public static class InventoryViewHolder extends RecyclerView.ViewHolder {

        TextView m_textItemName;
        TextView m_textQuantity;
        Button m_buttonEdit;
        Button m_buttonDelete;

        public InventoryViewHolder(@NonNull View itemView) {
            super(itemView);

            m_textItemName = itemView.findViewById(R.id.textItemName);
            m_textQuantity = itemView.findViewById(R.id.textQuantity);
            m_buttonEdit = itemView.findViewById(R.id.buttonEdit);
            m_buttonDelete = itemView.findViewById(R.id.buttonDelete);
        }
    }
}